#include <system_error>
import forge.expression.program;
import forge.expression.exceptions;
int main() {
   forge::expression::program exact{"math.mul_div(1000000000000000, 9999, 10000, rounding.ceil)"};
   if (exact.evaluate().value.as_int64() != 999900000000000LL) return 1;
   try {
      forge::expression::program invalid{"math.mul_div(1, 1, 0, rounding.trunc)"};
      (void)invalid.evaluate();
      return 2;
   } catch (const forge::exceptions::base& error) {
      if (error.code() != make_error_code(forge::expression::exceptions::code::evaluation_failed)) return 3;
   }
   return 0;
}
